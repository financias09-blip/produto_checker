# Produto Checker - Upload Único
Envie este ZIP ao GitHub. Depois crie o workflow `.github/workflows/build-from-zip.yml` com o conteúdo do README para gerar o APK.
