// main.dart placeholder; código completo será adicionado pelo pacote pronto.
void main() {}
